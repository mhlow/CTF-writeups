# NexusCTF: Disrupted Message
def rol8(x,r): return ((x<<r)|(x>>(8-r)))&0xFF
def ror8(x,r): return ((x>>r)|(x<<(8-r)))&0xFF

def decode(data):
    k=0x93; out=[]
    for i,c in enumerate(data):
        print(i, hex(c), hex(k))
    return bytes(out)

if __name__=='__main__':
    hexdata = open('ciphertext.txt').read().split()
    data = [int(b,16) for b in hexdata]
    msg = decode(data)
    print(msg.decode('ascii'))

