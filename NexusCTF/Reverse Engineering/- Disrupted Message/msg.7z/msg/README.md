# NEXUSCTF: COSMIC CHAOS
## Challenge: Encrypted Cargo Manifest

**Briefing – Polaris Logistics**  
A Polaris freighter transmitted a scrambled message before going offline.

### Objective
Recover the **ASCII plaintext** (64 characters, ends with a period) and submit as:
```
NexusCTF{<decoded_plaintext>}
```

### Files
- `ciphertext.txt` — the intercepted hex (29 bytes).
- `challenge.py`

All arithmetic is 8-bit.
